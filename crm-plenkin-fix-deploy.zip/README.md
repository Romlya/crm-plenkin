# CRM ПЛЕНКИН

Внутренняя CRM: канбан, сделки, смета, финансы, монтажники, склад.

## Что было сломано на Vercel

Фронт грузил куски `/js/app.full.0.js` … `app.full.9.js`, на деплое лежал обрезанный `app.full.1.js` → JS падал, разделы не открывались.

**Исправлено:** один бандл `app.bundle.js` + загрузчик `app.js`. Для старого кэша добавлены shim `app.full.0–9.js`.

## Важно про данные на Vercel

Хранилище — файл в `/tmp` + память инстанса. После cold start данные **могут обнулиться**.  
Для постоянного учёта лучше:

1. **Сервер (sweb / VPS)** — `node server/index.js` (файл `data/plenkin.json` на диске), или  
2. На Vercel регулярно **Экспорт/Импорт** бэкапа из Настроек (owner).

## Локальный запуск

```bash
cd crm-plenkin
npm install   # если нужно
node server/index.js
```

Открыть: http://localhost:3847

## Логины по умолчанию

| Логин | Пароль | Роль |
|-------|--------|------|
| owner | plenkin2026 | владелец |
| manager | manager2026 | менеджер |
| installer | montage2026 | монтажник |

Смените пароли после первого входа.

## Деплой на Vercel

- Root: репозиторий `crm-plenkin`
- Output: `public` (см. `vercel.json`)
- API: `api/index.js` → `server/api-handler.js`
- После пуша проверьте: `/js/app.bundle.js` отдаёт ~80KB, не 200 байт

## API (кратко)

- `GET /api/me`, `/api/board`, `/api/deals`, `/api/clients`, `/api/materials`
- `POST /api/login`, `/api/deals`, …
- `GET /api/export` · `POST /api/import` (owner)
